
# Calibration Example Data

Example stereo images for the `pyvale` stereo calibration example.

## Contents

- `cam0_frameXX_field0.bmp` — Images from camera 0  
- `cam1_frameXX_field0.bmp` — Images from camera 1  
- `cam0_data.csv` — Metadata for camera 0  
- `cam1_data.csv` — Metadata for camera 1  
- `stereo_data.csv` — Stereo pairing / correspondence data  

Each frame index corresponds to a synchronised stereo pair between camera 0 and camera 1.

## Usage

Download or clone this repository and place the data in a directory (e.g. `calibration-images`) alongside the example script. 
Make sure to unzip `calibration-images.zip`. Total size will be approx 2.9 GB.
